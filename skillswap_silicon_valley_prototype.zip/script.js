
function login(){
window.location='dashboard.html'
}

function subscribe(){
alert('Demo payment gateway: subscription activated')
}

function request(){
alert('Skill swap request sent')
}

function toggleDark(){
document.body.classList.toggle('dark')
}
